<?php
   function estabelerConexao()
   {
        // Deviam estar num ficheiro de configuração
       $hostname = "localhost";
       $databasename = "reclamacoes";
       $username = "user";
       $password = "1234";
       
       try {
           $conexao = new PDO("mysql:host=$hostname;dbname=$databasename;charset=utf8mb4",
                          $username, $password);
       }
       catch (\PDOException $e) {
           echo $e->getMessage();
       }
   
       return $conexao;
   
   }
   function registar()
   if (isset($_POST['registar'])){
      $username= mysql_real_escapeString($_POST['username']);
      $email= mysql_real_escapeString($_POST['email']);
      $password= mysql_real_escapeString($_POST['password']);
      if (empty($username)){
         array_push($erros,"insira um nome");
      }
      if (empty($email)){
         array_push($erros,"insira um email");
      }
      if (empty($password)){
         array_push($erros,"insira um password");
      }

      if (count($erros)== 0){
         $password = md5($password);
         $sql = "INSERT INTO user (username, email, password)
                        VALUES('$username','$email','$password')";
         mysqli_query($conexao,$sql);
      }


      
   }
?>