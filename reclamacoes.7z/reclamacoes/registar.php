<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Reclamações</title>
    <link rel="stylesheet" type="text/css" href="css/login.css">

    

    

    <!-- Bootstrap core CSS -->
    <!DOCTYPE html>
<html>
    
<head>
<div class="header">
        <h2>Registar</h2>
</div>
   
</head>

<body>
   
<form method="POST"  action="login.php">
    <div class="input-group">
        <label>Username</label>
        <input type="text" name="username">
</div>

<div class="input-group">
        <label>Email</label>
        <input type="text" name="email">
</div>

<div class="input-group">
        <label>Password</label>
        <input type="password" name="password">
</div>
<div class="input-group">
        <button type="submit" name="registar" class="btn">Registar</button>
</div>
<p>
    criar conta caso não não tenha<a href="registar.php"> Criar </a>
</p>

</body>

</html>
      
  </body>
</html>